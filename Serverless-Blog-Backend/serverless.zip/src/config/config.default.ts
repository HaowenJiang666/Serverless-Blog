export const middleware = ['errorMiddleware'];

export const orm = {
  type: 'mysql',
  host: 'rm-0xiofu01380ai668yxo.mysql.rds.aliyuncs.com',
  port: 3306,
  username: 'root',
  password: '41563102Jhw',
  database: 'blog',
  synchronize: true,
  logging: false,
};
