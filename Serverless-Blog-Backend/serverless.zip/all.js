const { BootstrapStarter } = require('@midwayjs/bootstrap');
const { Framework } = require('@midwayjs/faas');
const { asyncWrapper, start } = require('@midwayjs/serverless-fc-starter');
const { match } = require('path-to-regexp');

const layers = [];


let frameworkInstance;
let runtime;
let inited = false;
let initError;

const initializeMethod = async (initializeContext = {}) => {
  layers.unshift(engine => {
    engine.addRuntimeExtension({
      async beforeFunctionStart(runtime) {
        let startConfig = {
          initializeContext,
          preloadModules: [],
          applicationAdapter: runtime
        };
        let applicationContext;
        

        frameworkInstance = new Framework();
        frameworkInstance.configure({
          initializeContext,
          preloadModules: [],
          applicationAdapter: runtime
        });
        const boot = new BootstrapStarter();
        boot.configure({
          appDir: __dirname,
          
          applicationContext,
        }).load(frameworkInstance);

        await boot.init();
        await boot.run();
      }
    });
  })
  runtime = await start({
    layers: layers,
    initContext: initializeContext,
    runtimeConfig: {"service":{"name":"blog-server"},"provider":{"name":"aliyun"},"aggregation":{"all":{"functionsPattern":"*","handler":"all.handler","_isAggregation":true,"events":[{"http":{"method":"any","path":"/api/schema/*"}}],"_handlers":[{"handler":"schemaController.getLatestOne","events":{"http":{"path":"/api/schema/getLatestOne","method":["get"]}},"path":"/api/schema/getLatestOne","method":["get"]},{"handler":"schemaController.save","events":{"http":{"path":"/api/schema/save","method":["post"]}},"path":"/api/schema/save","method":["post"]}],"_allAggred":[{"path":"/api/schema/getLatestOne","method":["get"]},{"path":"/api/schema/save","method":["post"]}]}},"custom":{"customDomain":{"domainName":"auto"}},"functions":{"all":{"functionsPattern":"*","handler":"all.handler","_isAggregation":true,"events":[{"http":{"method":"any","path":"/api/schema/*"}}],"_handlers":[{"handler":"schemaController.getLatestOne","events":{"http":{"path":"/api/schema/getLatestOne","method":["get"]}},"path":"/api/schema/getLatestOne","method":["get"]},{"handler":"schemaController.save","events":{"http":{"path":"/api/schema/save","method":["post"]}},"path":"/api/schema/save","method":["post"]}],"_allAggred":[{"path":"/api/schema/getLatestOne","method":["get"]},{"path":"/api/schema/save","method":["post"]}]}},"package":{},"globalDependencies":{"@midwayjs/serverless-fc-starter":"2"}},
  });

  inited = true;
};

const getHandler = (hanlderName, ...originArgs) => {
  
    if (hanlderName === 'handler') {
      return  async (ctx) => {
        const allHandlers = [
  {
    "handler": "schemaController.getLatestOne",
    "events": {
      "http": {
        "path": "/api/schema/getLatestOne",
        "method": [
          "get"
        ]
      }
    },
    "path": "/api/schema/getLatestOne",
    "method": [
      "get"
    ],
    "router": "/api/schema/getLatestOne",
    "pureRouter": "/api/schema/getLatestOne",
    "regRouter": "/api/schema/getLatestOne",
    "level": 3,
    "paramsMatchLevel": 0
  },
  {
    "handler": "schemaController.save",
    "events": {
      "http": {
        "path": "/api/schema/save",
        "method": [
          "post"
        ]
      }
    },
    "path": "/api/schema/save",
    "method": [
      "post"
    ],
    "router": "/api/schema/save",
    "pureRouter": "/api/schema/save",
    "regRouter": "/api/schema/save",
    "level": 3,
    "paramsMatchLevel": 0
  }
];
        let handler = null;
        let ctxPath = ctx && ctx.path || '';
        let currentMethod = (ctx && ctx.method || '').toLowerCase();
        let matchRes;
        if (ctxPath) {
          handler = allHandlers.find(handler => {
            matchRes = match(handler.regRouter)(ctxPath);
            if (matchRes) {
              if (handler.method && handler.method.length && handler.method.indexOf(currentMethod) === -1) {
                return false;
              }
            }
            return matchRes;
          });
        }

        if (handler) {
          if (matchRes && matchRes.params) {
            const req = originArgs && originArgs[0];
            if (req) {
              req.pathParameters = Object.assign({}, matchRes.params, req.pathParameters);
            }
          }
          return frameworkInstance.handleInvokeWrapper(handler.handler)(ctx);
        }
        ctx.status = 404;
        ctx.set('Content-Type', 'text/html');
        return '<h1>404 Page Not Found</h1>';
      }; 
    }
  
}


 
exports.initializer = asyncWrapper(async (...args) => {
  try {
    if (!inited) {
      await initializeMethod(...args);
    }
  } catch (e) {
    initError = e;
    throw e;
  }
});


 


exports.handler = asyncWrapper(async (...args) => {
  try {
    if (!inited) {
      await initializeMethod();
    }
  } catch (e) {
    initError = e;
    throw e;
  }
  if (initError) {
    throw initError;
  }

  const handler = getHandler('handler', ...args);
  return runtime.asyncEvent(handler)(...args);
});



